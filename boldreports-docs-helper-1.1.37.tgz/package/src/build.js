const gulp = require('gulp');
const { rm, mkdir, cp, mv } = require('shelljs');
const { generateToc } = require('./toc.js');
const { sync } = require('glob');
const { repoName, repos, rootPath, copyrightPaths } = require('./config');
const runSequence = require('gulp4-run-sequence');
const { readFileSync, writeFileSync } = require('fs');
const { resolve } = require('path');

let copyrightYear = new Date().getFullYear();
gulp.task('clean', (done) => {
    const staticFiles = sync('./static/*', {
        ignore: ['./static/favicon*', './static/robots.txt', './static/assets', './static/404', './static/404.js', './static/404.html', './static/*.zip', './static/NotFoundPage', './static/css', './static/js', './static/img']
    });
    if (staticFiles.length) rm('-rf', staticFiles);
    rm('-rf', ['./.cache', './public', './src/pages']);
    mkdir('-p', './.cache');
    const leftToc = sync('./left-toc.json');
    if (leftToc.length) rm('-rf', leftToc);
    done();
});

gulp.task('copy', (done) => {
    mkdir('-p', './src/pages');
    cp('-r', './docs/*', './src/pages');
    cp('-r', './static/404.js', './src/pages');
    const API = sync('./API');
    if (API.length) cp('-r', './API/*', './static');
    if (repoName === repos.embedded.name) {
        mkdir('-p', './static/demos');
        cp('-r', './demos/*', './static/demos');
    }
    done();
});

gulp.task('toc', (done) => {
    generateToc();
    done();
});

const additionalPostInstallTask = (repoName === repos.embedded.name) ? ['copy-api-md'] : [];

gulp.task('postinstall', (done) => {
    runSequence('replace-gatsby-cli', 'copy-gatsby-template', 'copy-common-files', ...additionalPostInstallTask, done);
});

gulp.task('replace-gatsby-cli', (done) => {
    rm('-rf', './node_modules/gatsby/node_modules/gatsby-cli');
    const gatsbyCli = './node_modules/@boldreports/docs-helper/node_modules/gatsby-cli';
    if (sync(gatsbyCli).length) mv(gatsbyCli, './node_modules/');
    cp('-r', `./node_modules/gatsby-remark-image-attributes/package.json`, './node_modules/gatsby-remark-image-attributes/dist');
    done();
});

gulp.task('copy-gatsby-template', (done) => {
    cp('-r', `${rootPath}gatsby-template/*`, './');
    cp('-r', `${rootPath}gatsby-template/.htaccess`, './');
    done();
});

gulp.task('copy-404-js', (done) => {
    cp('-r', './static/404/404.js', './src/pages');
    done();
});

gulp.task('update-notfoundpage', (done) => {
    const toc = JSON.parse(readFileSync(resolve('./left-toc.json'), 'utf8'));
    var content = readFileSync('./static/404/404.js', 'utf-8');
    content = content.replace(/{{platform}}/g, toc.additionalInfo.header)
        .replace(/{{demoLink}}/g, toc.additionalInfo.url.demo)
        .replace(/{{cx}}/g, toc.cx);
    writeFileSync('./static/NotFoundPage/404.html', content);
    writeFileSync('./static/404/404.js', content);
    done();
});

gulp.task('copyright-update', (done) => {
    copyrightPaths.forEach((filePath) => {
        var content = readFileSync(filePath, 'utf-8');
        content = content.replace(/{{copyright}}/g, copyrightYear);
        writeFileSync(filePath, content);
    });
    done();
});

const additionalBuildTask = repoName === repos.embedded.name ? ['new-tab-generation'] : [];


gulp.task('build', (done) => {
    runSequence('clean', 'copy', 'toc', 'site-variables', 'update-notfoundpage', 'copyright-update', ...additionalBuildTask, done);
});

// Importing other task folders
if (repoName === repos.embedded.name) {
    require('require-dir')('./github');
}