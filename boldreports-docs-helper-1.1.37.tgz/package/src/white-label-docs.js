const gulp = require('gulp');
const { mkdir, cp, rm } = require('shelljs');
var fs = require('fs');
const runSequence = require('gulp4-run-sequence');
const { sync } = require('glob');
const { getRepoInfo, repoName } = require('./config');

var copyRightInfo = `/*!
*  filename: {{fileName}}
*  version : {{version}}
*  Copyright © 2001 - {{copyright}} Syncfusion Inc. All rights reserved.
*  Use of this code is subject to the terms of our license.
*  A copy of the current license can be obtained at any time by e-mailing
*  licensing@syncfusion.com. Any infringement will be prosecuted under
*  applicable laws. 
*/`

const ROOT_DEST = 'dist';

var copy = [
  {
    src: [
      'gulpfile.js',
      'gatsby-config.js',
      'gatsby-node.js',
      'config.json',
      'package.json',
      '.customnames',
      'node_modules/@boldreports/docs-helper/.spelling'
    ],
    dest: `${ROOT_DEST}`
  },
  {
    src: [
      'node_modules/@boldreports/docs-helper/src/build.js',
      'node_modules/@boldreports/docs-helper/src/config.js',
      'node_modules/@boldreports/docs-helper/src/content.js',
      'node_modules/@boldreports/docs-helper/src/production.js',
      'node_modules/@boldreports/docs-helper/src/tab.js',
      'node_modules/@boldreports/docs-helper/src/tile.js',
      'node_modules/@boldreports/docs-helper/src/serve.js',
      'node_modules/@boldreports/docs-helper/src/toc.js',
      'node_modules/@boldreports/docs-helper/src/test.js',
      'node_modules/@boldreports/docs-helper/src/file-validation.js',
      'node_modules/@boldreports/docs-helper/src/url-validation.js',
      'node_modules/@boldreports/docs-helper/config.json',
      'node_modules/@boldreports/docs-helper/src/lint',
      'node_modules/@boldreports/docs-helper/.spelling'
    ],
    dest:  `${ROOT_DEST}/build`,
  },
  {
    src: [
      'docs/*',
    ],
    dest: `${ROOT_DEST}/docs`
  },
  {
    src: [
      'static/*'
    ],
    dest: `${ROOT_DEST}/static`
  },
  {
    src: [
      'node_modules/@boldreports/docs-helper/src/gatsby-template/src/*'
    ],
    dest: `${ROOT_DEST}/src`
  },
  {
    src: [
      'API/*'
    ],
    dest: `${ROOT_DEST}/API`
  },
];


//Execute the task only for cloud and Enterprise platform
gulp.task('white-label-docs', (done) => {
  runSequence('copy-gulp-task', 'update-gulpfile', 'update-package-json', 'update-build-task', 'update-test-task', 'update-file-validation-task', 'update-content-js', 'update-gatsby-node-js', 'update-config-js', 'update-config-json', 'change-copyright-info', 'append-canonical', done);
});

gulp.task('change-copyright-info', (done) => {
  const fileArray = sync(`./${ROOT_DEST}/**/*.js`, { ignore: `./${ROOT_DEST}/node_modules/**/*` });
  for (i = 0; i < fileArray.length; i++) {
    var fileName = (/[^\/]+$/g).exec(fileArray[i])[0];
    var version = (/"siteVersion": "(.*?)",/g).exec(fs.readFileSync('./config.json'))[1];
    var copyRight = copyRightInfo.replace(/{{fileName}}/g, fileName).replace(/{{version}}/g, version)
    var content = fs.readFileSync(fileArray[i], 'utf8');
    fs.writeFileSync(fileArray[i], copyRight + "\n" + content);
  }
  done();
});

gulp.task('copy-gulp-task', (done) => {
  rm('-rf', `./${ROOT_DEST}`);
  for (i = 0; i < copy.length; i++) {
    if (!fs.existsSync(copy[i].dest)) {
      mkdir('-p', copy[i].dest);
    }
    cp('-r', copy[i].src, copy[i].dest);
  }
  done();
});

gulp.task('update-gulpfile', (done) => {
  var content = `var gulp = require("gulp");
require('require-dir')('./build');
module.exports = gulp;`
  fs.writeFileSync(`./${ROOT_DEST}/gulpfile.js`, content);
  done();
});

gulp.task('update-package-json', (done) => {
  var dependentPackages = (/"dependencies":\s+{([\s\S]*?)},/g).exec(fs.readFileSync('./node_modules/@boldreports/docs-helper/package.json', 'utf-8'))[1];
  var packageJsonContent = fs.readFileSync(`./${ROOT_DEST}/package.json`, 'utf8');
  packageJsonContent = packageJsonContent.replace(/"test":([\s\S]*?)"gulp publish",/g, '')
    .replace(/"@boldreports\/docs-helper":\s+"\*"/g, dependentPackages);
  fs.writeFileSync(`./${ROOT_DEST}/package.json`, packageJsonContent);
  done();
});

gulp.task('update-build-task', (done) => {
  var buildFile = fs.readFileSync(`./${ROOT_DEST}/build/build.js`, 'utf8');
  buildFile = buildFile
    .replace(/'site-variables',\s+/g, '')
    .replace(/'copy-gatsby-template',\s+'copy-common-files',\s+...additionalPostInstallTask,\s+/g, '')
    .replace(/gulp.task\('copy-gatsby-template'([\s\S]*?)}\);/g, '')
    .replace(/.\/node_modules\/@boldreports\/docs-helper/g, '.')
    .replace(/if\s+\(repoName\s+(.*)[\s\S]*?}/g, '')
    .replace(/const\s+additionalPostInstallTask\s+(.*)/g, '')
    .replace(/const additionalBuildTask\s+(.*)/g, '')
    .replace(/...additionalBuildTask,\s+/g, '')
    .replace(/\/\/ Importing other task folders/, '');
  fs.writeFileSync(`./${ROOT_DEST}/build/build.js`, buildFile);
  done();
});

gulp.task('update-test-task', (done) => {
  var testFile = fs.readFileSync(`./${ROOT_DEST}/build/test.js`, 'utf8');
  testFile = testFile
    .replace(/const additionalTestTask(.*)/g, '')
    .replace(/...additionalTestTask,/g, '')
    .replace(/'common-file-validation',/g, '')
    .replace(/'seo-validation',/g, '');
  fs.writeFileSync(`./${ROOT_DEST}/build/test.js`, testFile);
  done();
});

gulp.task('update-file-validation-task', (done) => {
  var fileValidation = fs.readFileSync(`./${ROOT_DEST}/build/file-validation.js`, 'utf8');
  fileValidation = fileValidation
    .replace(/const { getIgnoredFiles }(.*)/g, '')
    .replace(/let filteredDir(.*)/g, '')
    .replace(/folderNames = folderNames(.*)/g, '')
    .replace(/let commonIgnoredFiles(.*)/g, '')
    .replace(/, ...commonIgnoredFiles.fileList/g, '');
  fs.writeFileSync(`./${ROOT_DEST}/build/file-validation.js`, fileValidation);
  done();
});

gulp.task('update-content-js', (done) => {
  var content = fs.readFileSync(`./${ROOT_DEST}/build/content.js`, 'utf8');
  content = content
    .replace(/const { updateReleaseNotes }(.*)/g, '')
    .replace(/const releaseNotes(.*)/g, '')
    .replace(/function isReleaseNotes\(routerPath, toc\) {(.*|[\r\n])+?\}/g, '')
    .replace(/if \(isReleaseNotes\(routerPath, toc\)\) {(.*|[\r\n])+?\}/g, `
      mdcontent = createTab(mdcontent, routerPath);
      mdcontent = createTiles(mdcontent, currentFile);
      return mdcontent;
    }}`)
    .replace(/isReleaseNotes: isReleaseNotes/g, '');
  fs.writeFileSync(`./${ROOT_DEST}/build/content.js`, content);
  done();
});

gulp.task('update-gatsby-node-js', (done) => {
  var gatsbyNodeJS = fs.readFileSync(`./${ROOT_DEST}/gatsby-node.js`, 'utf8');
  var hLevel = (/if \(!\(isReleaseNotes && releaseNotes.some\(\(exp\) => header.match\(exp\)\)\)\) {([\s\S]*?)}[\r\n]/g).exec(gatsbyNodeJS)[1];
  gatsbyNodeJS = gatsbyNodeJS
    .replace(/node_modules\/@boldreports\/docs-helper\/src/g, 'build')
    .replace(/, isReleaseNotes\(slug\)/g, '')
    .replace(/, isReleaseNotes/g, '')
    .replace(/const releaseNotes(.*)/g, '')
    .replace(/if \(!\(isReleaseNotes && releaseNotes.some\(\(exp\) => header.match\(exp\)\)\)\) {([\s\S]*?)}[\r\n]/g, hLevel);
  fs.writeFileSync(`./${ROOT_DEST}/gatsby-node.js`, gatsbyNodeJS);
  done();
});

gulp.task('update-config-js', (done) => {
  var configJS = fs.readFileSync(`./${ROOT_DEST}/build/config.js`, 'utf8');
  configJS = configJS.replace(/node_modules\/@boldreports\/docs-helper/g, 'build')
    .replace(/'.\/..\/',\s+'config.json'/g, `'./', 'config.json'`)
    .replace(/const\s+commonFiles\s+=(.*)/g, '')
    .replace(/const\s+platform\s+=(.*)/g, `const platform = { "platformOrder": [] };`)
    .replace(/commonFiles:(.*)/g, '')
    .replace(/baseUrl:(.*)/g, '')
    .replace(/apiBaseFolder:(.*)/g, '')
    .replace(/demos:[\s\S]*?},/g, '');
  fs.writeFileSync(`./${ROOT_DEST}/build/config.js`, configJS);
  done();
});

gulp.task('update-config-json', (done) => {
  var config = fs.readFileSync(`./${ROOT_DEST}/build/config.json`, 'utf8');
  var name = (/"name":\s+"(.*?)"/g).exec(fs.readFileSync('./package.json', 'utf8'))[1];
  var regex = new RegExp(`"\\w+":\\s+{\\s+"name":\\s+"` + name + `"(?=.*\\s)[^{}]+\}`);
  var currentRepo = regex.exec(config)[0];
  currentRepo = currentRepo.replace(/"cx": "(.*?)"/g, `"cx": ""`);
  var content = `{"repos": {\n ${currentRepo} }}`;
  fs.writeFileSync(`./${ROOT_DEST}/build/config.json`, content);

  var rootConfig = fs.readFileSync(`./${ROOT_DEST}/config.json`, 'utf8');
  fs.writeFileSync(`./${ROOT_DEST}/config.json`, '{' + (/"additionalInfo"[\s\S]*}/g).exec(rootConfig)[0]);
  done();
});

gulp.task('append-canonical', (done) => {
  const docsFileArray = sync(`./${ROOT_DEST}/docs/**/*.md`);
  for (var i = 0; i < docsFileArray.length; i++) {
    var fileName = (/\/docs\/(.*).md/g).exec(docsFileArray[i])[1];
    fileName = fileName.replace('/index','').replace('/overview','');
    var content = fs.readFileSync(docsFileArray[i], 'utf-8');
    if ((/canonical:\s+(.*)/g).exec(content) !== null) {
      var relativeURL = (/canonical:\s+(.*)/g).exec(content)[1].replace(/''/g, '');
      content = content.replace((/canonical:\s+(.*)/g).exec(content)[1], `https://help.boldreports.com${relativeURL}`);
      fs.writeFileSync(docsFileArray[i], content);
    }
    else {
      const regexExp = new RegExp(/---(.*?)---/, 's');
      let frontmatterTemplate = regexExp.exec(content)[1];
      frontmatterTemplate += `canonical: https://help.boldreports.com/${getRepoInfo(repoName).url}/${fileName}/\n`
      const regexResult = regexExp.exec(content)[1];
      fs.writeFileSync(docsFileArray[i], content.replace(regexResult, frontmatterTemplate));
    }
  }
  const apiFileArray = sync(`./${ROOT_DEST}/API/**/index.html`);
  for (var i = 0; i < apiFileArray.length; i++) {
    var apiFileName = (/\/API\/(.*?)\/index.html/g).exec(apiFileArray[i])[1];
    var apiContent = fs.readFileSync(apiFileArray[i], 'utf-8');
    var canonicalTag = (/<title>(.*?)<\/title>/g).exec(apiContent)[0];
    canonicalTag += `\n<link rel="canonical" href="https://help.boldreports.com/${getRepoInfo(repoName).url}/${apiFileName}/">`;
    apiContent = apiContent.replace(/<title>(.*?)<\/title>/g, canonicalTag);
    fs.writeFileSync(apiFileArray[i], apiContent);
  }
  done();
});