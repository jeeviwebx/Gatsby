const { readFileSync } = require('fs');
const { resolve, join } = require('path');

const repoConfig = JSON.parse(readFileSync(resolve('./config.json'), 'utf8'));
const docConfig = JSON.parse(readFileSync(join(__dirname, './../', 'config.json'), 'utf8'));
const config = { ...docConfig, ...repoConfig };
const platform = JSON.parse(readFileSync(resolve('./platform-order.json'), 'utf8'));
const packageConfig = JSON.parse(readFileSync(resolve('./package.json'), 'utf8'));
const commonFiles = JSON.parse(readFileSync(resolve('./common-files.json'), 'utf8'));

function getToc() {
    return JSON.parse(readFileSync(resolve('./left-toc.json'), 'utf8'));
}

const repoInfos = config.repos;

function getRepoInfo(repoName) {
    return repoInfos[Object.keys(repoInfos).find(repo => repoInfos[repo].name === repoName)];
}

module.exports = {
    rootPath: './node_modules/@boldreports/docs-helper/src/',
    baseUrl: `https://${config.publish.bucketName}`,
    platformOrder: platform.platformOrder,
    releaseVersion: config.siteVersion,
    config: config,
    getToc: getToc,
    repoName: packageConfig.name,
    commonFiles: commonFiles,
    apiBaseFolder: 'api-reference',
    demos: {
        javascript: 'javascript-reporting',
        angular: 'angular-reporting'
    },
    repos: repoInfos,
    largerSizeCommonFileRepo: config.largerSizeCommonFileRepo,
    getRepoInfo: getRepoInfo,
    copyrightPaths: [
        './src/templates/layout.js',
        './static/404/404.js',
        './static/NotFoundPage/404.html',
        './node_modules/@boldreports/docs-helper/src/white-label-docs.js'
    ]
};
