call git pull
call gulp docs-publish --targetBranch %1 --siteVersion %2 --umsVersion %3