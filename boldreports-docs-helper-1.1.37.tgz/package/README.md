# Docs helper

Contains the build tasks and configuration files for report documentation

## Gulp tasks

### NPM package Publish

Run the below command to publish the `@boldreports/docs-helper` to Nexus repository manager.

```cmd
    gulp publish
```

### Documentation Publish

Run the below command to publish all the platforms documentation to AWS S3 bucket.

```cmd
    gulp docs-publish
```

> We have provided `{{platform-url}}` template. This template will be replaced by individual repository URL at execution. it will be usefull for prefix flag.

#### Flags

* `--platforms=embedded,enterprise` flag is used to publish the specific platform documentation to AWS S3 bucket.

> We need to provide the platform name seperated by comma. Refer `repos` key from `config.json` file for the platform names.

* `--clean=true` flag is used to delete/clean the publish folder completely before the publish task.

> In general, We will remove `@boldreports/docs-helper` package from `node_modules` folder and reinstall the package. so, this will install only new `@boldreports/docs-helper` package which will reduce the time drastically for the repeated publish. If you want to compleltely remove the `node_modules` folder, specify this flag.

* `--pdf=true` flag is used to generate PDF for the documentation.

> To Publish the All Repositories
```cmd
gulp docs-publish --allPlatforms true
```

## Nexus Domain Update

In order to update the nexus domain url, need to replace the nexus domain in `config.json` and `.npmrc` file by the new domain to be updated.